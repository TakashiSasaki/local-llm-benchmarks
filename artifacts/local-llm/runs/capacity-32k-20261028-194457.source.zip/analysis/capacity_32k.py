"""Isolated 32K capacity check; each model runs alone; no evaluation profiles edited."""
import copy, datetime, hashlib, json, pathlib, socket, sys, time, traceback, urllib.request, zipfile
ROOT=pathlib.Path(r'C:\LocalLLM')
sys.path.insert(0,str(ROOT/'scripts'))
import server
from benchmark import common_text
from grading import capture_lock
from memory import Monitor, snapshot

stamp=datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
report_path=ROOT/'runs'/f'capacity-32k-{stamp}.json'
archive=ROOT/'runs'/f'capacity-32k-{stamp}.source.zip'

def post(base,path,data,timeout=60):
    req=urllib.request.Request(base+path,data=json.dumps(data,ensure_ascii=False).encode('utf-8'),headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=timeout) as response: return json.load(response)

def main():
    check=capture_lock(); lock=ROOT/'validation/suite-lock.json'
    if (ROOT/'server-state.json').exists(): raise RuntimeError('Existing server state; will not start or stop it')
    with socket.socket() as s:
        s.settimeout(1)
        if s.connect_ex(('127.0.0.1',8089))==0: raise RuntimeError('Port 8089 is occupied')
    lock_data=json.loads(lock.read_text(encoding='utf-8'))
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for name,expected in lock_data.items():
            p=ROOT/name
            if hashlib.sha256(p.read_bytes()).hexdigest()!=expected: raise RuntimeError('Suite source changed: '+name)
            z.write(p,name.replace('\\','/'))
        z.write(lock,'validation/suite-lock.json'); z.write(pathlib.Path(__file__),'analysis/capacity_32k.py')
    data={'status':'running','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'purpose':'32K isolated capacity, not task quality or sustained stability',
          'source_archive':str(archive),'source_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
          'suite_lock_sha256':hashlib.sha256(lock.read_bytes()).hexdigest(),
          'context_requested':32768,'target_input_tokens':31800,'generated_token_limit':64,
          'limits':['F16 KV and evaluation placement retained','one synthetic raw completion per model',
                    'No SSH, multi-turn agent, quality, sustained-load or long-context retrieval test',
                    'RAM and GPU sampled periodically; peaks may be missed','OS file cache not cleared'], 'models':[]}
    def save(): report_path.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    save(); loader=server.load_profile
    try:
        for model in ('qwen','lfm','glm'):
            if not check(): raise RuntimeError('Suite changed during capacity test')
            if (ROOT/'server-state.json').exists(): raise RuntimeError('Existing server state; will not start or stop it')
            base=loader(model); p=copy.deepcopy(base); p['profile_id']=f'{model}-capacity32k-{stamp}'
            p['context_tokens']=32768; args=p['server_args']; args[args.index('-c')+1]='32768'
            row={'model':model,'profile':p,'status':'starting','passed':False}; data['models'].append(row); save()
            server.load_profile=lambda name,model=model,p=p: copy.deepcopy(p) if name==model else loader(name)
            mon=None
            try:
                server.start(model); state=json.loads((ROOT/'server-state.json').read_text(encoding='utf-8'))
                if state.get('profile_id')!=p['profile_id']: raise RuntimeError('Server identity mismatch')
                row['server_start']=state; row['after_load']=snapshot(state['pid'])
                if row['after_load']['available_ram_bytes']<2*1024**3: raise RuntimeError('Less than 2 GiB free RAM after model load')
                if row['after_load']['gpu_used_mib'] is None or row['after_load']['gpu_used_mib']>7900: raise RuntimeError('GPU memory telemetry unavailable or too little margin')
                mon=Monitor(state['pid'],ROOT/'runs'/f"{p['profile_id']}.memory.jsonl").start()
                low,high=1,2000; best=None
                while low<=high:
                    middle=(low+high)//2; prompt=common_text(middle)+'\nRespond with OK.'
                    count=len(post(p['base_url'],'/tokenize',{'content':prompt,'add_special':True})['tokens'])
                    if count<=31800: best=(prompt,count); low=middle+1
                    else: high=middle-1
                if best is None or best[1]<31000: raise RuntimeError('Could not construct >=31K token input')
                prompt,count=best; row.update(status='generating',input_tokens=count); save()
                print(json.dumps({'model':model,'stage':'generating','input_tokens':count}),flush=True)
                payload={'prompt':prompt,'n_predict':64,'ignore_eos':True,'stream':False,'cache_prompt':False,'seed':p['seed'],**p['sampling']}
                started=time.perf_counter(); response=post(p['base_url'],'/completion',payload,timeout=240)
                row.update(status='complete',wall_seconds=time.perf_counter()-started,tokens_evaluated=response.get('tokens_evaluated'),
                           tokens_predicted=response.get('tokens_predicted'),truncated=response.get('truncated'),
                           timings=response.get('timings'),stop_type=response.get('stop_type'),content=response.get('content'))
                row['passed']=(row['tokens_evaluated'] is not None and row['tokens_evaluated']>=31000 and row['tokens_predicted']==64 and row['truncated'] is False)
                if not row['passed']: row['failure']='Completion did not confirm >=31K evaluated tokens, 64 generated, and no truncation'
            except Exception as exc:
                row.update(status='failed',error=str(exc),traceback=traceback.format_exc())
            finally:
                if mon is not None: row['memory']=mon.stop()
                state_path=ROOT/'server-state.json'
                if state_path.exists():
                    state=json.loads(state_path.read_text(encoding='utf-8'))
                    if state.get('profile_id')!=p['profile_id']: raise RuntimeError('Server ownership changed; not stopping it')
                    server.stop()
                server.load_profile=loader; save()
                print(json.dumps({'model':model,'stage':'finished','status':row['status'],'passed':row['passed'],'error':row.get('error')}),flush=True)
        if not check(): raise RuntimeError('Suite changed before completion')
        data.update(status='complete',finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),suite_lock_unchanged=True); save()
    finally: server.load_profile=loader
    print(json.dumps({'report':str(report_path),'status':data['status']}),flush=True)

if __name__=='__main__': main()
