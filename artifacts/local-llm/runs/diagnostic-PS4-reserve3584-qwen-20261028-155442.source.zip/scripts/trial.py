"""Create fresh fixtures, run one model task, then validate outside the agent."""
import argparse, datetime, json
from agent import run
from bootstrap import Bridge
from fixtures import TASKS, prepare, prompt
from grading import capture_lock, grade_b4, grade_ps4, snapshot, static_grade
from server import ROOT

def trial(profile,task,alias=None):
    check=capture_lock(); trial_id=datetime.datetime.now().strftime('%Y%m%d-%H%M%S')+'-'+profile
    local,definition=prepare(task,trial_id); remote=None; bridge=None
    if task.startswith(('B','S')):
        if not alias: raise ValueError('SSH task requires --host')
        bridge=Bridge(alias); remote=bridge.host['workspace_root'].rstrip('/')+'/'+trial_id+'/'+task
        seeded=bridge({'action':'seed','directory':remote,'files':definition['remote'],'executable':definition['executable']})
        (ROOT/'runs'/f'fixture-{trial_id}-{task}.json').write_text(json.dumps({'local':str(local),'remote':seeded},ensure_ascii=False,indent=2),encoding='utf-8')
    config=json.loads((ROOT/'executor-config.json').read_text(encoding='utf-8-sig'))
    def validate(events):
        remote_files=bridge({'action':'snapshot','directory':remote})['files'] if bridge else {}
        result=static_grade(task,snapshot(local),remote_files,lock_valid=check())
        if task=='PS4': result['dynamic']=grade_ps4(local,config['powershell']); result['passed'] &= result['dynamic']['passed']
        if task=='B3':
            invocation=bridge({'action':'invoke','directory':remote,'script':'broken.sh','args':[]})
            result['dynamic']={'passed':invocation['exit_code']==0,'exit_code':invocation['exit_code']}; result['passed'] &= result['dynamic']['passed']
            after=static_grade(task,snapshot(local),bridge({'action':'snapshot','directory':remote})['files'],lock_valid=check())
            result['after_reexecution']=after; result['passed'] &= after['passed']
        if task=='B4': result['dynamic']=grade_b4(bridge,remote); result['passed'] &= result['dynamic']['passed']
        trace={}
        parsed=[]
        for e in events:
            try: parsed.append((e['call']['function']['name'],json.loads(e['call']['function']['arguments']),e['result']))
            except Exception: pass
        if task=='S2':
            trace['explicit_cwd_env_on_multiple_calls']=sum(1 for name,args,r in parsed if name=='run_ssh_bash' and args.get('host_alias')==alias and args.get('cwd','').rstrip('/')==remote+'/work' and args.get('env',{}).get('BUILD_LABEL')=='日本語 label' and args.get('env',{}).get('REGION')=='test-east' and r.get('status') in ['running','completed'])>=2
        if task=='S3':
            remote_jobs={r['job_id'] for name,args,r in parsed if name=='run_ssh_bash' and args.get('host_alias')==alias and r.get('job_id')}
            trace['polled_remote_job']=any(name=='poll_process' and args.get('job_id') in remote_jobs for name,args,r in parsed)
        if task=='S4':
            for direction in ['upload','download']:
                trace[direction+'_completed']=any(name=='transfer_file' and args.get('host_alias')==alias and args.get('direction')==direction and r.get('exit_code')==0 for name,args,r in parsed)
        trace['no_wrong_ssh_host']=not any(name in ['run_ssh_bash','transfer_file'] and args.get('host_alias')!=alias for name,args,r in parsed)
        result['execution_trace']=trace; result['passed'] &= all(trace.values())
        # Check again after executing repaired programs to detect grader changes.
        result['lock_after_dynamic']=check(); result['passed'] &= result['lock_after_dynamic']
        return result
    return run(profile,prompt(task,local,remote,alias),local,task_id=task,limit=480 if task in ['S3','S4'] else 300,validator=validate,lock_check=check)

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--profile',required=True,choices=['qwen','lfm','glm']); ap.add_argument('--task',required=True,choices=list(TASKS)); ap.add_argument('--host'); a=ap.parse_args()
    trial(a.profile,a.task,a.host)
