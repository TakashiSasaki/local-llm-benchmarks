"""SSH preflight, helper installation and fixture bridge. Only configured hosts."""
import argparse, base64, hashlib, json, pathlib, shlex, subprocess
from server import ROOT

class Bridge:
    def __init__(self,alias):
        self.config=json.loads((ROOT/'executor-config.json').read_text(encoding='utf-8-sig'))
        self.alias=alias; self.host=self.config['ssh_hosts'][alias]
    def ssh(self,command,stdin=None,timeout=30):
        p=subprocess.run([self.config['ssh'],'-T','-o','BatchMode=yes','-o','ConnectTimeout=10',self.alias,command],input=stdin,capture_output=True,timeout=timeout)
        if p.returncode: raise RuntimeError(p.stderr.decode('utf-8',errors='replace')+p.stdout.decode('utf-8',errors='replace'))
        return p.stdout
    def __call__(self,payload):
        source=(ROOT/'scripts/remote_helper.py').read_bytes()
        encoded=base64.b64encode(source).decode()
        command='python3 -c '+shlex.quote("import base64; exec(compile(base64.b64decode('"+encoded+"'),'<validator-bridge>','exec'))")
        return json.loads(self.ssh(command,json.dumps(payload,ensure_ascii=False).encode(),timeout=60))
    def preflight(self):
        remote_root=pathlib.PurePosixPath(self.host['workspace_root']).parent
        # Require a dedicated absolute directory; never install into the home root.
        if not remote_root.is_absolute() or len(remote_root.parts)<4: raise ValueError('Dedicated remote root required')
        code='''import hashlib,json,os,pathlib,platform,shutil,subprocess,sys
r=json.load(sys.stdin)
if platform.system()!='Linux': raise RuntimeError('SSH evaluation requires an actual Linux peer')
root=pathlib.Path(r['root']); root.mkdir(parents=True,exist_ok=True)
worker=pathlib.Path(r['worker']); worker.parent.mkdir(parents=True,exist_ok=True)
content=bytes.fromhex(r['source_hex'])
if worker.exists() and worker.read_bytes()!=content: raise RuntimeError('Existing remote worker differs; review before replacing')
worker.write_bytes(content)
pathlib.Path(r['workspace']).mkdir(parents=True,exist_ok=True)
pathlib.Path(r['state']).mkdir(parents=True,exist_ok=True)
print(json.dumps({'hostname':platform.node(),'platform':platform.platform(),'python':sys.version,'bash':shutil.which('bash'),'bash_version':subprocess.check_output(['bash','--version'],text=True).splitlines()[0],'sha256sum':shutil.which('sha256sum'),'worker_sha256':hashlib.sha256(content).hexdigest(),'root':str(root)}))
'''
        payload={'root':str(remote_root),'worker':self.host['worker_path'],'workspace':self.host['workspace_root'],'state':self.host['state_root'],'source_hex':(ROOT/'scripts/executor_worker.py').read_bytes().hex()}
        command='python3 -c '+shlex.quote(code)
        result=json.loads(self.ssh(command,json.dumps(payload).encode(),timeout=30))
        if not result['bash']: raise RuntimeError('Remote bash is missing')
        (ROOT/'runs'/f'ssh-preflight-{self.alias}.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
        return result

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('host_alias'); a=ap.parse_args()
    print(json.dumps(Bridge(a.host_alias).preflight(),ensure_ascii=False))
