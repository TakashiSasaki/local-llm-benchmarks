"""Tool contract. SSH targets come only from a configured allowlist."""
import base64, hashlib, json, pathlib, shlex, subprocess, uuid
from executor_worker import check_cwd, launch, poll, stop
from server import ROOT

def schema(name,description,properties,required):
    return {'type':'function','function':{'name':name,'description':description,'parameters':{'type':'object','properties':properties,'required':required,'additionalProperties':False}}}
STR={'type':'string'}
RUN={'script':STR,'cwd':STR,'env':{'type':'object','additionalProperties':{'type':'string'}},'timeout':{'type':'number','minimum':0,'maximum':60}}
TOOLS=[schema('run_powershell','Windowsの新しいPowerShell 7プロセスで実行。cwdとenvは毎回明示。timeoutは最大60秒の待機時間で、超過してもjobは続く。',RUN,['script','cwd']),
       schema('run_ssh_bash','許可済みSSH hostで新しいBashプロセスを実行。状態は毎回リセット。待機超過時はjob_idをpollする。',{**RUN,'host_alias':STR},['host_alias','script','cwd']),
       schema('poll_process','管理jobの完了と追記出力を確認。offsetは前回のnext_offsetを指定。',{'job_id':STR,'stdout_offset':{'type':'integer','minimum':0},'stderr_offset':{'type':'integer','minimum':0}},['job_id']),
       schema('stop_process','管理jobのプロセスグループを停止し、実際の終了を確認。',{'job_id':STR},['job_id']),
       schema('transfer_file','許可済みSSH hostとのファイル転送。local_pathとremote_pathは絶対パス。',{'host_alias':STR,'direction':{'type':'string','enum':['upload','download']},'local_path':STR,'remote_path':STR},['host_alias','direction','local_path','remote_path'])]

class Executor:
    def __init__(self,workspace=None):
        self.workspace=str(pathlib.Path(workspace or ROOT/'workspace').resolve())
        pathlib.Path(self.workspace).mkdir(parents=True,exist_ok=True)
        self.config=json.loads((ROOT/'executor-config.json').read_text(encoding='utf-8-sig'))
        self.registry=ROOT/'jobs-registry.json'
        self.index=ROOT/'jobs-index'; self.index.mkdir(exist_ok=True)
        self.started_jobs=set()
    def jobs(self): return json.loads(self.registry.read_text()) if self.registry.exists() else {}
    def remember(self,job_id,alias):
        self.started_jobs.add(job_id)
        path=self.index/(job_id+'.json')
        if not path.exists(): path.write_text(json.dumps({'host_alias':alias}),encoding='utf-8')
    def job_info(self,job_id):
        if len(job_id)!=32 or any(c not in '0123456789abcdef' for c in job_id): raise ValueError('Invalid managed job id')
        path=self.index/(job_id+'.json')
        return json.loads(path.read_text()) if path.exists() else self.jobs().get(job_id)
    def not_started(self,job_id,alias):
        self.started_jobs.discard(job_id)
        (self.index/(job_id+'.json')).write_text(json.dumps({'host_alias':alias,'state':'not_started'}),encoding='utf-8')
    def register(self,result,alias):
        self.remember(result['job_id'],alias)
        return self.decode(result)
    def remote(self,alias,payload):
        host=self.config['ssh_hosts'].get(alias)
        if host is None: raise ValueError('host_alias is not configured')
        command='python3 '+shlex.quote(host['worker_path'])
        p=subprocess.run([self.config['ssh'],'-T','-o','BatchMode=yes','-o','ConnectTimeout=10',alias,command],input=json.dumps(payload,ensure_ascii=False).encode('utf-8'),capture_output=True,timeout=90)
        if p.returncode:
            try: error=json.loads(p.stdout)
            except ValueError: error={}
            if error.get('type')=='ValueError': raise ValueError(error.get('error','Remote request rejected'))
            raise RuntimeError(p.stderr.decode('utf-8',errors='replace')+p.stdout.decode('utf-8',errors='replace'))
        result=json.loads(p.stdout)
        if result.get('error'): raise RuntimeError(result['error'])
        return result
    def decode(self,result):
        for name in ['stdout','stderr']:
            data=base64.b64decode(result.pop(name+'_base64',''))
            result[name]=data.decode('utf-8',errors='replace')
        return result
    def execute(self,name,args):
        if name=='run_powershell':
            check_cwd(args['cwd'],self.workspace)
            job_id=uuid.uuid4().hex; self.remember(job_id,None)
            try: result=launch({**args,'job_id':job_id,'state_root':str(ROOT/'jobs'),'workspace_root':self.workspace,'host':'windows-local','powershell':self.config['powershell']})
            except KeyboardInterrupt: raise
            except Exception as e:
                if not (ROOT/'jobs'/job_id/'worker.json').exists() and not (ROOT/'jobs'/job_id/'process.json').exists():
                    self.not_started(job_id,None); raise
                return {'job_id':job_id,'status':'unknown','exit_code':None,'host':'windows-local','error':str(e),'may_be_running':True}
            return self.register(result,None)
        if name=='run_ssh_bash':
            a=dict(args); alias=a.pop('host_alias'); h=self.config['ssh_hosts'].get(alias)
            if h is None: raise ValueError('host_alias is not configured')
            job_id=uuid.uuid4().hex; self.remember(job_id,alias)
            try: result=self.remote(alias,{'action':'start',**a,'job_id':job_id,'state_root':h['state_root'],'workspace_root':h['workspace_root'],'host':alias})
            except ValueError: self.not_started(job_id,alias); raise
            except KeyboardInterrupt: raise
            except Exception as e: return {'job_id':job_id,'status':'unknown','exit_code':None,'host':alias,'error':str(e),'may_be_running':True}
            return self.register(result,alias)
        if name in ['poll_process','stop_process']:
            job=self.job_info(args['job_id'])
            if job is None: raise ValueError('unknown managed job')
            alias=job['host_alias']; action='poll' if name=='poll_process' else 'stop'
            if job.get('state')=='not_started': return {'job_id':args['job_id'],'status':'not_started','exit_code':None,'host':alias or 'windows-local'}
            if alias:
                h=self.config['ssh_hosts'][alias]
                return self.decode(self.remote(alias,{'action':action,**args,'state_root':h['state_root']}))
            if not (ROOT/'jobs'/args['job_id']/'request.json').exists():
                self.not_started(args['job_id'],None)
                return {'job_id':args['job_id'],'status':'not_started','exit_code':None,'host':'windows-local'}
            result=poll(str(ROOT/'jobs'),**args) if action=='poll' else stop(str(ROOT/'jobs'),args['job_id'])
            return self.decode(result)
        if name=='transfer_file':
            alias=args['host_alias']; h=self.config['ssh_hosts'].get(alias)
            if h is None: raise ValueError('host_alias is not configured')
            local=pathlib.Path(args['local_path']).resolve(); remote=args['remote_path']
            if not local.is_relative_to(pathlib.Path(self.workspace)): raise ValueError('local_path outside workspace')
            if not remote.startswith(h['workspace_root'].rstrip('/')+'/') or '..' in pathlib.PurePosixPath(remote).parts: raise ValueError('remote_path outside workspace')
            target=f'{alias}:{remote}'
            if args['direction']=='upload': src,dst=str(local),target
            elif args['direction']=='download': src,dst=target,str(local)
            else: raise ValueError('invalid transfer direction')
            p=subprocess.run([self.config['scp'],'-B','-o','ConnectTimeout=10',src,dst],capture_output=True,timeout=120)
            return {'host':alias,'status':'completed','exit_code':p.returncode,'stderr':p.stderr.decode('utf-8',errors='replace'),'local_path':str(local),'remote_path':remote,'bytes':local.stat().st_size if local.exists() else None,'local_sha256':hashlib.sha256(local.read_bytes()).hexdigest() if local.is_file() else None,'remote_sha256':None,'real_execution':True}
        raise ValueError('unknown tool')
